<?php
 
 if ($_SERVER['REQUEST_METHOD'] === 'POST')

{
	 $username=$_POST['username']; 
	 $password=$_POST['password'];
	 
 if ($username=="delta" && $password=="power") {
  echo '<script>window.location="dashboard/bootback.php"</script>';}
                      //msg for correct credential }
 else {
  $message = "Username and/or Password incorrect.\\nTry again.";
         echo "<script type='text/javascript'>alert('$message')</script>";
        //page which will be displaied after unsuccessfull login
}
}

?>

<!-- /*
 * ---------------------------------------------------------------
 *  HTML CODE BEGINS FROM HERE
 * ---------------------------------------------------------------
 */ -->

<!DOCTYPE.html>
<html>
<meta name="viewport" content="width=device-width, initial scale=1.0">
<HEAD>
  <link rel="stylesheet" type="text/css" href="dashboard/bootstrap/css/styles.css">
    <style>
      
      img.logo{display: block;
    
    margin-left: auto;
    margin-right: auto;
    height: 80px; width: 200px;}
   

    </style>
  
  <TITLE>
    Login Page
  </TITLE>
  <script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
  </script>
</HEAD>

<body> 
    
  <div class="header">

    <img src="images/index1.png" class="logo" alt="Delta logo">
  
  </div> 
  
    <p class="pre">
      In order to maintain web access security do not leave<br>your pc unattended when logged in.Be sure to close<br>all open browser sessions when finished."
    </p>
    <br>
    <button onClick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>
<!-- /*
 * ---------------------------------------------------------------
 *  MODEL CODE BEGINS FROM HERE
 * ---------------------------------------------------------------
 */ -->
<div id="id01" class="modal">
  
  <form class="modal-content animate" action="" method="post">
    <div class="imgcontainer">
      <span onClick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avatar.png" alt="Avatar" class="avatar" style="width: 128px; height: 128px">
    </div>
    
    <div class="container">
      <label for="uname" style="color: #1E90FF"><b>Username</b></label>
      <input type="text" id="fname" name="username" placeholder="username..">
      
    <label for="password" style="color: #1E90FF"><b>Password</b></label>
     <input type="password" id="password" name="password" placeholder="password..">
    
      <button type="submit" name="login">Login</button>
      
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onClick="document.getElementById('id01').style.display='none'" class="cancelbtn" >Cancel</button>
      
    </div>
  </form>
</div>

    <p class="pre">Web browser request came from IPv4 client,so we<br>are using address 172.24.5.222<br><br>Click this link to make IPv6 request :<br>
      <a href="https://www.google.com">https://www.google.com</a><br><br>
    <p class="site">Site summary</p><hr width="20%"><br></p>
      <address>
        Company<br>
        Site<br>
        Model<br>
        Serial No
      </address>
    
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }

}
</script>  

  </body>

</html>
