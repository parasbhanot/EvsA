#ifndef GPIO_H
#define GPIO_H

/*
    include files
*/

#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
    hash defines
*/

#define IN  0
#define OUT 1

#define LOW  0
#define HIGH 1

//controls
#define DO1 "PB4"     //DO1 J65 Right Most IN_CONTACTOR
#define DO2 "PB9"     //DO2 J65 2nd but right most  -- LVD_3_4 controlled from this
#define DO3 "PA24"    //DO3 one but , NOZZLE1_LOCK
#define DO4 "PA25"    //DO4 Left Most, NOZZLE1_UNLOCK
#define DO5 "PD2"     //DO5, CN48, LVD1_2
#define DO6 "PD3"     //DO6,CN46  // Aux is controlled from this, AUX

#define MAINS_LED    "PD14"
#define ONOFF_LED    "PD15"
#define CHARGING_LED "PD16"
#define SYSERR_LED   "PD17"

/*
    Function decaration
*/

int GPIOUnexport(int pin);
int GPIOExport(int pin);
int GPIODirection(const char *pin, int dir);
int GPIORead(const char *pin);
int GPIOWrite(const char *pin, int value);
#endif // GPIO_H



