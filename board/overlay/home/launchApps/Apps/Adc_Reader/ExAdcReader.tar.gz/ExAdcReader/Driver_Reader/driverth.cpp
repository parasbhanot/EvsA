
#include"driver_opertions.h"
#include "pthread.h"
#include <unistd.h>
#include <qdebug.h>

void * iosPollingThread(void *arg)
{
    Driver_Opertions *dop = (Driver_Opertions *)arg;
    char sendCommand[100];

    while(1)
    {
        if(dop->init_All_Drivers())
        {
            //update_Modal(); // only run if init of all is sucessfull
            //fprintf(stderr,"Drive init Successfull");

            qDebug("Drive init Successfull");
            break;
        }
        else {

            qDebug("Driver Init fail \n");
            sleep(5);
        }
    }

    while(1)
    {

        //dop->update_InternalAdc();
        //dop->update_Modbus();
        //dop->update_Adc(1);

        sleep(6);
        qDebug("Thread0 Live");

        sprintf(sendCommand,"echo %f > /tmp/shuntCurrent.txt",dop->sc_2);
        system(sendCommand);

        sprintf(sendCommand,"echo %f > /tmp/shuntCurrent2.txt",dop->sc);
        system(sendCommand);

        sprintf(sendCommand,"echo %f > /tmp/temperature.txt",dop->ct);
        system(sendCommand);

        qDebug("Channels-1_4 %2.4f, %2.4f, %2.4f\n",dop->sc,dop->sc_2,dop->ct);

    }
    qDebug("Thread0 Exiting");

}

void * iosPollingThread1(void *arg)
{
    Driver_Opertions *dop = (Driver_Opertions *)arg;

    //if(dop->init_All_Drivers()){
    //  qDebug("Drive init Successfull");
    //}

    while(dop->initDone == false) sleep(1);

    while(1)
    {
            dop->update_Adc();

            qDebug() << "Cabinet Temp" << dop->ct;
            qDebug() << "Shunt Current" << dop->sc;
            qDebug() << "Shunt Current 2", dop->sc_2;

            sleep(1);
    }
}

void startIoPolling(Driver_Opertions * dop){

    pthread_t pth_adc;
    pthread_t pth_modbus;
    pthread_create(&(pth_modbus), NULL, iosPollingThread,(void *)dop);
    pthread_create(&(pth_adc), NULL, iosPollingThread1,(void *)dop);
}

