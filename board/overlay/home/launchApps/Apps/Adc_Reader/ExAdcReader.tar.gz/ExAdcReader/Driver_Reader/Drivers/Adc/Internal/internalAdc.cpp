#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <arpa/inet.h>
#include <linux/spi/spidev.h>

//#define ADC_LOG

int ADC_Channnel_Volatge_Read(int channel_no)
{
#define VALUE_MAX 100
    char path[VALUE_MAX];
    char value_str[3];
    int fd;

    snprintf(path, VALUE_MAX, "/sys/bus/iio/devices/iio\:device0/in_voltage%d_raw", channel_no);

    #ifdef ADC_LOG
    printf("\n%s\n\n",path);
    #endif

    fd = open(path, O_RDONLY);
    if (-1 == fd) {
        fprintf(stderr, "Failed to open %s gpio value for reading!\n",channel_no);
        return(-1);
    }

    if (-1 == read(fd, value_str, 6)) {
        fprintf(stderr, "Failed to read value!\n");
        return(-1);
    }

    close(fd);

    return(atoi(value_str));
}

float get_scale_value()
{
#define VALUE_MAX 100
    char path[VALUE_MAX];
    char value_str[3];
    int fd;

    snprintf(path, VALUE_MAX, "/sys/bus/iio/devices/iio\:device0/in_voltage_scale");

    #ifdef ADC_LOG
    printf("\n%s\n\n",path);
    #endif

    fd = open(path, O_RDONLY);
    if (-1 == fd) {
        fprintf(stderr, "Failed to get scale value for reading!\n");
        return(-1);
    }

    if (-1 == read(fd, value_str, 6)) {
        fprintf(stderr, "Failed to read value!\n");
        return(-1);
    }

    close(fd);

    return(atof(value_str));
}

bool readInternalAdc(float *v11,float *v2,float *t1, float *t2){

    float an5_gain = 1;
    float an6_gain = 1;
    float an7_gain = 1;
    float an8_gain = 1;

    float an5_offset = 0;
    float an6_offset = 0;
    float an7_offset = 0;
    float an8_offset = 0;


    int x,y,z,a;

    float scale = get_scale_value();

    float voltage,voltage2,v,v1;

    float resistance,Temperature,resistance1,Temperature1;

    int i;

    float sum_voltage=0,sum_voltage2=0,sum_tempearature1=0,sum_tempearature2=0;

    for(i=0;i<100;i++)
    {

        x = ADC_Channnel_Volatge_Read(4);

        voltage = x*scale/20;
        sum_voltage += voltage;

        a=ADC_Channnel_Volatge_Read(5);

        voltage2=a*scale/20;

        sum_voltage2+=voltage2;


        y=ADC_Channnel_Volatge_Read(10);

        v=y*scale/2000;

        resistance= (3600*v)/(5-v);

        Temperature =(resistance-1000)/3.85;

        sum_tempearature1 += Temperature;


        z = ADC_Channnel_Volatge_Read(11);

        v1 = z*scale/2000;

        resistance1= (3600*v1)/(5-v1);

        Temperature1 =(resistance1-1000)/3.85;

        sum_tempearature2 += Temperature1;

    }

    *v11 = ((sum_voltage /100 ) * an5_gain) - 0.65; // Need to explore this formula?
    *v2 = ((sum_voltage2 /100 ) * an6_gain) - 0.65;//....
    *t1 = ((sum_tempearature1 /100 ) * an7_gain) - an7_offset;//....
    *t2 = ((sum_tempearature2 /100 ) * an8_gain) - an8_offset;//....

    return true;

}

