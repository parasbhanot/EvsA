int init_Adc_spi(void);
int txrxspi(uint8_t *tx, uint8_t *rx,uint8_t len);
float adc1valueget(void);
float adc2valueget(void);
float adc3valueget(void);
float adc4valueget(void);
