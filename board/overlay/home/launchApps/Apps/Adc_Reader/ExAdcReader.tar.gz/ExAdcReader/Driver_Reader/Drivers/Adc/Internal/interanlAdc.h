
#ifndef INTERNAL_ADC_H
#define INTERNAL_ADC_H

int ADC_Channnel_Volatge_Read(int channel_no);
float get_scale_value();

bool readInternalAdc(float *v11,float *v2,float *t1, float *t2);
#endif //end of file
