#ifndef SPI_H 
#define SPI_H

#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

/**
   Function declarations 
*/
bool init_spi();
void deinit_spi();
void pabort(const char *s);
void setVoltageCurrent(int volt, int curr);

#endif
