
#include <stdint.h>
#include <unistd.h>
#include <string.h>

#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
int ret_rect = 0;
int fd_rect = 0;

unsigned char done=0;

const char *device = "/dev/spidev32765.0";
uint8_t mode = 1;
uint8_t bits = 8;
uint32_t speed = 500000;
uint16_t delay;

uint8_t txrect[10] = {
        0x01, 0x00, 0x94, 0x11, 0xE8, 0x03,
        0x00, 0x00, 0x00, 0x00,
    };

uint8_t txrectBkp[10] = {
        0x01, 0x00, 0x94, 0x11, 0xE8, 0x03,
        0x00, 0x00, 0x00, 0x00,
    };

void pabort(const char *s)
{
    perror(s);
    abort();
}

void setVoltageCurrent(int volt, int curr)
{
    txrect[2] = (uint8_t)(volt & 0x000000ff);
    txrect[3] = (uint8_t)((volt >> 8) & 0x000000ff);

    txrect[4] = (uint8_t)(curr & 0x000000ff);
    txrect[5] = (uint8_t)((curr >> 8) & 0x000000ff);

}

void transfer(int fd, uint8_t *tx, int len)
{
    int ret;

    uint8_t rx[len] = {0, };
    struct spi_ioc_transfer tr;

    tr.tx_buf=(unsigned long)tx;
    tr.rx_buf=(unsigned long)rx;
    //tr.len=ARRAY_SIZE(tx);
    tr.len = len;
    tr.delay_usecs=delay;
    tr.speed_hz=0;
    tr.bits_per_word=0;

    ret = ioctl(fd, SPI_IOC_MESSAGE(1), &tr);

    if (ret == 1)
        pabort("can't send spi message");
    /* jeet
    for (ret = 0; ret < len; ret++) {
        if (!(ret % 6))
            puts("");
        printf("%.2X ", rx[ret]);
    }
    puts("");
    */
}

//Pthread...........
void *rectifier_set(void* arg)
{
    while(1)
    {
        if(fd_rect >= 0)
        {
            transfer(fd_rect, txrect, ARRAY_SIZE(txrect));
            memcpy(txrectBkp, txrect, sizeof(txrect));

            sleep(1);

            if(memcmp(txrectBkp, txrect, sizeof(txrect)) != 0)
            {
                transfer(fd_rect, txrect, ARRAY_SIZE(txrect));
            }
        }
        sleep(1);
    }
}

bool init_spi()
{
    int set_Count = 0;

    fd_rect = open(device, O_RDWR);
    if (fd_rect < 0){
         pabort("can't open device");
    }else {
        set_Count++;
    }


    /*
     * spi mode
     */
    ret_rect = ioctl(fd_rect, SPI_IOC_WR_MODE, &mode);
    if (ret_rect == -1){
        pabort("can't set spi mode");
    }else{

        set_Count++;
    }

    ret_rect = ioctl(fd_rect, SPI_IOC_RD_MODE, &mode);
    if (ret_rect == -1){
         pabort("can't get spi mode");
    }
    else {

        set_Count++;
    }

    /*
     * bits per word
     */
    ret_rect = ioctl(fd_rect, SPI_IOC_WR_BITS_PER_WORD, &bits);
    if (ret_rect == -1){
        pabort("can't set bits per word");
    }else{

        set_Count++;
    }


    ret_rect = ioctl(fd_rect, SPI_IOC_RD_BITS_PER_WORD, &bits);
    if (ret_rect == -1){

        pabort("can't get bits per word");
    }else{

        set_Count++;
    }


    /*
     * max speed hz
     */
    ret_rect = ioctl(fd_rect, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
    if (ret_rect == -1){
          pabort("can't set max speed hz");
    }else{

        set_Count++;
    }


    ret_rect = ioctl(fd_rect, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
    if (ret_rect == -1){
        pabort("can't get max speed hz");
    }else{

        set_Count++;
    }

    printf("spi mode: %d\n", mode);
    printf("bits per word: %d\n", bits);
    printf("max speed: %d Hz (%d KHz)\n", speed, speed/1000);

    if(set_Count == 7){
        return true;
    }else{
        return false;
    }

}

void deinit_spi()
{
  close(fd_rect);

}

#else

uint8_t tx[10] = {
        0x01, 0x00, 0x94, 0x11, 0xE8, 0x03,
        0x00, 0x00, 0x00, 0x00,
    };


void setVoltageCurrent(int volt, int curr)
{
    tx[2] = (uint8_t)(volt & 0x000000ff);
    tx[3] = (uint8_t)((volt >> 8) & 0x000000ff);

    tx[4] = (uint8_t)(curr & 0x000000ff);
    tx[5] = (uint8_t)((curr >> 8) & 0x000000ff);

}
#endif
