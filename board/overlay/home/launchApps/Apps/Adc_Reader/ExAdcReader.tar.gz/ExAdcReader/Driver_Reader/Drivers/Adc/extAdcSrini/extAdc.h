float calculate_channel_voltage0(int fd,uint8_t *tx);
void pabort_adc(const char *s);
int adc_spi_initialize();
extern int fd_adc;
