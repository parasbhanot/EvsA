#include <iostream>

#include "driver_opertions.h"
#include "Drivers/Spi/spi.h"
#include "Drivers/Adc/External/extAdc.h"

#include <qdebug.h>

using namespace std;

Driver_Opertions::Driver_Opertions()
{

    initDone = false;
}

bool  Driver_Opertions::init_All_Drivers()
{
    if(init_Adc_spi() == 1){
        initDone = true;
        return true;
    } else{
        qDebug("adc init failed");
        return false;
    }
}

void Driver_Opertions::update_Adc(){

        // both internal and external adc must be ua
        //AN1
        //float volt=calculate_channel_voltage0(fd_adc,tx0);

        float volt = adc1valueget();
        sleep(1);
        volt = adc1valueget();
        sleep(1);
        volt = adc1valueget();

        float cabinet_temp = volt;

        //AN2
        //sleep(1);
        //volt = adc2valueget();
        //sleep(1);
        //volt = adc2valueget();
        //sleep(1);
        //volt = adc2valueget();

        //float CC2 = volt;
        //printf("\n voltage2 is %f: ", CC2);

        //AN3
        //sleep(1);
        //volt = adc3valueget();
        //sleep(1);
        //volt = adc3valueget();
        //sleep(1);
        //volt = adc3valueget();

        //float shunt_current_2 = volt*150;

        float shunt_current_2 = 0;

        //AN4
        sleep(1);
        volt = adc4valueget();
        sleep(1);
        volt = adc4valueget();
        sleep(1);
        volt = adc4valueget();

        float shunt_current = volt;

        //printf("Cabinet Temp: %f \n", cabinet_temp);
        //printf("Shunt Current: %f \n", shunt_current);
        //printf("Shunt Current 2: %f \n", shunt_current_2);

        ct = cabinet_temp;
        sc = shunt_current;
        sc_2 = shunt_current_2;
}
