#include <QCoreApplication>
#include "Driver_Reader/driver_opertions.h"

void startIoPolling(Driver_Opertions * dop);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Driver_Opertions *dop = new Driver_Opertions();
    startIoPolling(dop);
    return a.exec();
}
