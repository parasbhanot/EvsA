#ifndef DRIVER_OPERTIONS_H
#define DRIVER_OPERTIONS_H

class Driver_Opertions
{
public:
    Driver_Opertions();
    void update_Adc();
    bool initDone;
    bool init_All_Drivers();
    float ct;
    float sc;
    float sc_2;
};

#endif // DRIVER_OPERTIONS_H
